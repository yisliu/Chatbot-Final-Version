import java.util.Scanner;
import java.util.concurrent.TimeUnit;


import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class Main
{
     static   Scanner in = new Scanner (System.in);//Creates scanner object.
          static     double total = 0;





       public static void main(String[] args) throws InterruptedException
       {



               System.out.println("Bot: Welcome to McDonald's!");
               TimeUnit.SECONDS.sleep(1);
               System.out.println("        ████████████████████        \n" + //
                                       "      ██                    ██      \n" +//
                                       "    ██                        ██    \n" + //
                                       "  ██                            ██  \n" + //
                                       "  ██                            ██  \n" + //
                                       "  ██                            ██  \n" + //
                                       "██                                ██\n" + //
                                       "████████████████████████████████████\n" + //
                                       "██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██\n" + //
                                       "  ████████████████████████████████  \n" + //
                                       "██                                ██\n" + //
                                       "  ██    ██    ██████    ██    ████  \n" + //
                                       "  ██████  ████      ████  ████  ██  \n" + //
                                       "  ██                            ██  \n" + //
                                       "    ████████████████████████████    \n" + //
                                       "");
               System.out.println("Bot: Home of the cheeseburger!");
               TimeUnit.SECONDS.sleep(2);

               String a[] = {"Ciao", "Bonjour", "Hola", "Aloha", "Guten Tag", "Hello"};
               int r = (int)(Math.random()*a.length);
               System.out.println("Bot: " + a[r] + ", welcome to McDonalds! Home of the golden arches.");
               System.out.println("Bot: As an AI chatbot, I am here to help you order your meal.");
               System.out.println("Bot: Would you like to order, get a rec, or see the menu first? ");


        String[] drinkMenu = {"Bot: Here is the drink menu", "Got the drink menu- ", "Sure! Here is the McDonald's drink menu"};
        String[] thanks = {"Bot: Of course! let me know if you need anything else!", "At your service! Let me know if you need more assistance "};
        String[] error = {"Bot: I didn't catch that...", "I didn't quite understand...", "Hmmm... I didn't get that...", "I didn't get that, can you repeat that?", "Whoops! I didn't get that, can you repeat that?"};
               String[] end = {"Nice chat, have a great day!", "Hope I was able to help with everything, have a fabulous day!", "I hope everything was good, have a great day!", "Bye", "Farewell", "Till the next time we see each other", "See ya soon!", "Bye, have a fabulous day!"};
               String[] recOrder = {"Big Mac", "Quarter Pounder", "McDouble", "Hamburger", "Cheeseburger","bacon, egg & cheese mcgriddles",
                                       "sausage mcgriddles",
                                       "sausage, egg & cheese mcgriddles",
                                       "big breakfast",
                                       "big breakfast with hotcakes",
                                       "hotcakes",
                                       "hotcakes and sausage",
                                       "sausage burrito",
                                       "hash browns",
                                       "fruit & maple oatmeal",
                                       "egg mcmuffin meal",
                                       "sausage mcmuffin with egg meal",
                                       "sausage biscuit with egg meal",
                                       "bacon, egg & cheese biscuit meal",
                                       "bacon, egg & cheese mcgriddles meal",
                                       "sausage, egg & cheese mcgriddles meal",
                                       "sausage mcgriddles meal",
                                       "sausage burrito meal", "McCrispy", "Deluxe McCrispy", "Spicy McCrispy", "Spicy Chicken Sandwich", "Fillet-O-Fish", "McChicken", "World Famous Fries®",
                                      "Apple Slices",
                                      "Tangy Barbeque Sauce",
                                      "Spicy Buffalo Sauce",
                                      "Creamy Ranch Sauce",
                                      "Honey Mustard Sauce",
                                      "Honey",
                                      "Sweet 'N Sour Sauce",
                                      "Ketchup Packet",
                                      "Mustard Packet",
                                      "Mayonnaise Packet", "hamburger happy meal",
                                       "4 piece chicken mcnuggets happy meal",
                                       "6 piece chicken mcnuggets happy meal",  "mcflurry with oreo cookies",
                                       "mcflurry with m&m's candies",
                                       "vanilla cone",
                                       "chocolate shake",
                                       "vanilla shake",
                                       "strawberry shake",
                                       "hot fudge sundae",
                                       "hot caramel sundae",
                                       "baked apple pie",
                                       "chocolate chip cookie", "Chicken McNuggets", "nuggets", "Coca-Cola", "Sprite", "Dr Pepper", "Fanta", "Strawberry Banana Smoothie", "Frozen Coca-Cola", "Mango Pinapple Smoothie", "Dulce de Leche Frappé",
                                    "mccafe caramel macchiato",
                                        "mccafe cappuccino",
                                        "mccafe caramel cappuccino",
                                        "mccafe french vanilla cappuccino",
                                        "mccafe mocha latte",
                                        "americano",
                                        "mccafe premium roast coffee",
                                        "mccafe iced caramel macchiato",
                                        "mccafe iced mocha latte",
                                        "mccafe iced coffee",
                                        "mccafe iced caramel coffee",
                                        "mccafe iced french vanilla coffee",
                                        "mccafe latte",
                                        "mccafe iced latte",
                                        "mccafe caramel latte",
                                        "mccafe iced caramel latte",
                                        "mccafe french vanilla latte",
                                        "mccafe iced french vanilla latte",
                                        "mccafe caramel frappe",
                                        "mccafe mocha frappe"};
               String[] drinks = {"Coca-Cola", "Sprite", "Dr Pepper", "Fanta", "Strawberry Banana Smoothie", "Frozen Coca-Cola", "Mango Pinapple Smoothie", "Dulce de Leche Frappé",
                                   "McCafé® Caramel Macchiato",
                                   "McCafé® Cappuccino",
                                   "McCafé® Caramel Cappuccino",
                                   "McCafé® French Vanilla Cappuccino",
                                   "McCafé® Mocha Latte",
                                   "Americano",
                                   "McCafé® Premium Roast Coffee",
                                   "McCafé® Iced Caramel Macchiato",
                                   "McCafé® Iced Mocha Latte",
                                   "McCafé® Iced Coffee",
                                   "McCafé® Iced Caramel Coffee",
                                   "McCafé® Iced French Vanilla Coffee",
                                   "McCafé® Latte",
                                   "McCafé® Iced Latte",
                                   "McCafé® Caramel Latte",
                                   "McCafé® Iced Caramel Latte",
                                   "McCafé® French Vanilla Latte",
                                   "McCafé® Iced French Vanilla Latte",
                                   "McCafé® Caramel Frappé",
                                   "McCafé® Mocha Frappé"};
               String[] burgers = {"Big Mac", "Quarter Pounder", "McDouble", "Hamburger", "Cheeseburger"};
               String[] breakfast1 = {"bacon, egg & cheese mcgriddles",
                                         "sausage mcgriddles",
                                         "sausage, egg & cheese mcgriddles",
                                         "big breakfast",
                                         "big breakfast with hotcakes",
                                         "hotcakes",
                                         "hotcakes and sausage",
                                         "sausage burrito",
                                         "hash browns",
                                         "fruit & maple oatmeal",
                                         "egg mcmuffin meal",
                                         "sausage mcmuffin with egg meal",
                                         "sausage biscuit with egg meal",
                                         "bacon, egg & cheese biscuit meal",
                                         "bacon, egg & cheese mcgriddles meal",
                                         "sausage, egg & cheese mcgriddles meal",
                                         "sausage mcgriddles meal",
                                         "sausage burrito meal"};
               String[] breakfast = {
                           "Bacon, Egg & Cheese McGriddles®",
                           "Sausage McGriddles®",
                           "Sausage, Egg & Cheese McGriddles®",
                           "Big Breakfast®",
                           "Big Breakfast® with Hotcakes",
                           "Hotcakes",
                           "Hotcakes and Sausage",
                           "Sausage Burrito",
                           "Hash Browns",
                           "Fruit & Maple Oatmeal",
                           "Egg McMuffin® Meal",
                           "Sausage McMuffin® with Egg Meal",
                           "Sausage Biscuit with Egg Meal",
                           "Bacon, Egg & Cheese Biscuit Meal",
                           "Bacon, Egg & Cheese McGriddles® Meal",
                           "Sausage, Egg & Cheese McGriddles® Meal",
                           "Sausage McGriddles® Meal",
                           "Sausage Burrito Meal"
                       };
               String[] chickFish = {"McCrispy", "Deluxe McCrispy", "Spicy McCrispy", "Spicy Chicken Sandwich", "Fillet-O-Fish", "McChicken"};
               String[] saucesAndSides = {
                   "World Famous Fries®",
                   "Apple Slices",
                   "Tangy Barbeque Sauce",
                   "Spicy Buffalo Sauce",
                   "Creamy Ranch Sauce",
                   "Honey Mustard Sauce",
                   "Honey",
                   "Sweet 'N Sour Sauce",
                   "Ketchup Packet",
                   "Mustard Packet",
                   "Mayonnaise Packet"
               };

               String[] happyMeals = {
                   "Hamburger Happy Meal®",
                   "4 Piece Chicken McNuggets® Happy Meal®",
                   "6 Piece Chicken McNuggets® Happy Meal®"
               };
               String[] happyMeals1 = {"hamburger happy meal",
                                          "4 piece chicken mcnuggets happy meal",
                                          "6 piece chicken mcnuggets happy meal"};

               String[] sweet = {
                   "McFlurry® with OREO® Cookies",
                   "McFlurry® with M&M'S® Candies",
                   "Vanilla Cone",
                   "Chocolate Shake",
                   "Vanilla Shake",
                   "Strawberry Shake",
                   "Hot Fudge Sundae",
                   "Hot Caramel Sundae",
                   "Baked Apple Pie",
                   "Chocolate Chip Cookie"
               };
               String[] sweet1 = { "mcflurry with oreo cookies",
                                     "mcflurry with m&m's candies",
                                     "vanilla cone",
                                     "chocolate shake",
                                     "vanilla shake",
                                     "strawberry shake",
                                     "hot fudge sundae",
                                     "hot caramel sundae",
                                     "baked apple pie",
                                     "chocolate chip cookie"};
               String[] nuggets = {"Chicken McNuggets"};

               String[] drinks1 = {"Coca-Cola", "Sprite", "Dr Pepper", "Fanta", "Strawberry Banana Smoothie", "Frozen Coca-Cola", "Mango Pinapple Smoothie", "Dulce de Leche Frappé",
                                 "mccafe caramel macchiato",
                                     "mccafe cappuccino",
                                     "mccafe caramel cappuccino",
                                     "mccafe french vanilla cappuccino",
                                     "mccafe mocha latte",
                                     "americano",
                                     "mccafe premium roast coffee",
                                     "mccafe iced caramel macchiato",
                                     "mccafe iced mocha latte",
                                     "mccafe iced coffee",
                                     "mccafe iced caramel coffee",
                                     "mccafe iced french vanilla coffee",
                                     "mccafe latte",
                                     "mccafe iced latte",
                                     "mccafe caramel latte",
                                     "mccafe iced caramel latte",
                                     "mccafe french vanilla latte",
                                     "mccafe iced french vanilla latte",
                                     "mccafe caramel frappe",
                                     "mccafe mocha frappe"};
               String[] checkError ={"Bot: I didn't quite get that (ᗒᗣᗕ)՞ let's try again, would you like to order, get a rec, or see a menu first", "Bot: That's not on the menu (づ￣ ³￣)づ let's backtrack, would you like to order, get a rec or see a menu first?","I'm sorry, what? (|||❛︵❛。) let's take it from the top, would you like to order, get a rec or see a menu first?"};


                String userResp = in.nextLine();



        while(!userResp.equals("bye") && !userResp.equals("done") && !userResp.equals("ttyl") && !userResp.equals("talk to you later") && !userResp.equals("finished")){

                if(userResp.contains("rec")){
                        System.out.println(getRecommendationBasedOnTime());

                        userResp = in.nextLine();
                }
                else if(userResp.contains("order")){
                                System.out.println("Bot: what do you want to order?");
                                        userResp = in.nextLine();

                                      if(checkMenu(recOrder, userResp, total)){
                                              total = add(userResp, total);
                                              userResp = in.nextLine();

                                      }
                                        else{
                                        System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                                                userResp = in.nextLine();

                                        }

                        }
                        else if(userResp.contains("menu") && !userResp.contains("breakfast") && !userResp.contains("burgers") && !userResp.contains("drink") && !userResp.contains("sauces") && !userResp.contains("sides") && !userResp.contains("sweet") && !userResp.contains("dessert") && !userResp.contains("nugget") && !userResp.contains("chicken") && !userResp.contains("fish") && !userResp.contains("sandwich")){
                                        System.out.println("Would you like to see the menu for burgers, drinks, breakfast, chicken and fish, sauces and sides, or sweets?");
                                          userResp = in.nextLine();
                                }

 else if (userResp.contains("burger")){
         System.out.println("Bot: Here is the burger menu:");
                        menuOut(burgers);
                        userResp = in.nextLine();
                       if(userResp.contains("yes")){
                               System.out.println("Okay! What would you like to order?");
                               userResp = in.nextLine();
                               if(checkMenu(burgers, userResp, total)){
                                       System.out.println("Bot: Added that to your order!");
                                        total = add(userResp, total);
                               userResp = in.nextLine();
                               }

                               else{
                                       System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                                        userResp = in.nextLine();
                               }

                }

 }



                else if (userResp.contains("drink")){
                        System.out.println("Bot: " + drinkMenu[(int)(Math.random()*drinkMenu.length)]);
                        menuOut(drinks);
                        System.out.println("Bot: Would you like to order any drinks? Please type yes or no. (´_｀。) ");


                        userResp = in.nextLine();
                        if(userResp.contains("yes")){
                                System.out.println("Okay! What would you like to order? Please type in lowercase! ");
                                String userResp2 = in.nextLine();
                                if(checkMenu(drinks1, userResp2, total)){
                                        System.out.println("Bot: Added that to your order!");
                                         total = add(userResp, total);
                                userResp = in.nextLine();
                                }
                                else{
                                        System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                                         userResp = in.nextLine();
                                }



                                }
                        else{
                                System.out.println("Bot: Ok! Let me know what you need- whether it's a rec, menu, or order!");
                                userResp = in.nextLine();
                        }

                }




                //yum...
                else if (userResp.contains("breakfast")){
                        System.out.println("Bot: Here is the breakfast menu:");

                        menuOut(breakfast);

                        System.out.println("Say yes to order from this menu, and no if you want to do something else.");
                        userResp = in.nextLine();
                        if(userResp.contains("yes")){
                        System.out.println("Okay! What would you like to order?");
                        userResp = in.nextLine();

                        if(checkMenu(breakfast1, userResp, total)){
                        System.out.println("Bot: Added that to your order!");
                                 total = add(userResp, total);
                                userResp = in.nextLine();
                                }
                else{ System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                                         userResp = in.nextLine();
                                }

                }

                }

                else if (userResp.contains("chicken") || userResp.contains("fish") || userResp.contains("sandwich")) {
                        menuOut(chickFish);
                         userResp = in.nextLine();

                        if(checkMenu(chickFish, userResp, total)){
                                       System.out.println("Bot: Added that to your order!");
                                 total = add(userResp, total);
                                       userResp = in.nextLine();
                               }
                               else{
                                       System.out.println("Bot: " + error[(int)(Math.random()*error.length)]);
                               }

                }



                else if(userResp.contains("nugget")){
                        System.out.println("Seems like you want nuggets, I'll add that to your order!");
                         userResp = "chicken mcnuggets";
                        if(checkMenu(nuggets, userResp, total)){

                                 userResp = "chicken mcnuggets";
                       total = add(userResp, total);
                                  System.out.println("Bot: added that to your order!");
                                       userResp = in.nextLine();
                               }

                }

                else if(userResp.contains("sweet") || userResp.contains("dessert")){
                        menuOut(sweet);
                         userResp = in.nextLine();
                        if(checkMenu(sweet, userResp, total)){
                                       System.out.println("Bot: Added that to your order!");

                                       userResp = in.nextLine();
                               }
                               // else{
                               //         System.out.println("Bot: " + error[(int)(Math.random()*error.length)]);
                               // }
                              else{
                        System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                              }

                }

                else if(userResp.contains("sides") || userResp.contains("sauce")){
                        menuOut(saucesAndSides);
                        userResp = in.nextLine();
                        if(checkMenu(saucesAndSides, userResp, total)){
                                       System.out.println("Bot: Added that to your order!");

                                       userResp = in.nextLine();
                               }
                               // else{
                               //         System.out.println("Bot: " + error[(int)(Math.random()*error.length)]);
                               // }
                               else{
                        System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                               }

                }


                else if(userResp.contains("happy meal") || userResp.contains("for children")){
                        menuOut(happyMeals);
                        userResp = in.nextLine();
                        if(checkMenu(happyMeals, userResp, total)){
                                       System.out.println("Bot: Added that to your order!");

                                       userResp = in.nextLine();
                               }
                               else{
                                       System.out.println(checkError[(int)(Math.random()*checkError.length)]);
                               }
                }
                else{
                        System.out.println(error[(int)(Math.random()*error.length)]);
                        userResp = in.nextLine();
                }

                }
               if(total != 0){
               System.out.println("Bot: Thanks for ordering with the McDonald's chatbot. Your total is " + total + " dollars, have a great day!");
               }
               else{
                       System.out.println(end[(int)(Math.random()*end.length)]);

               }
                        }//main method ends




        public static void menuOut(String a[]) throws InterruptedException{

                for(int i = 0; i<a.length; i++){

                        System.out.println("-" + a[i] + "\n");

                }



        }




public static boolean checkMenu(String a[], String w, double total) throws InterruptedException{
        w = w.toLowerCase();

        for(int i = 0; i<a.length; i++){
                    String temp = a[i].toLowerCase();
                a[i] = a[i].toLowerCase();
                if(w.contains(a[i])== true){
                    System.out.println("adding...");
                        TimeUnit.SECONDS.sleep(1);
                        System.out.println(".");
                        TimeUnit.SECONDS.sleep(1);
                        System.out.println(".");
                        TimeUnit.SECONDS.sleep(1);
                        System.out.println(".");


                        return true;
                }
        }



        return false;
}
 public static double add(String here, double total){

               if(here.contains("big mac") || here.contains("quarter pounder")
                 || here.contains("mcdouble") || here.contains("hamburger") || here.contains("cheeseburger")){
                       total += 5;
                        System.out.println("Total: $" + total);

               }
               else if (here.contains("coca-cola") || here.contains("sprite") || here.contains("dr pepper")
                         || here.contains("fanta") || here.contains("strawberry banana smoothie")
                         || here.contains("frozen coca-cola") || here.contains("mango pineapple smoothie")
                         || here.contains("dulce de leche frappe") || here.contains("mccafe caramel macchiato")
                         || here.contains("mccafe cappuccino") || here.contains("mccafe caramel cappuccino")
                         || here.contains("mccafe french vanilla cappuccino") || here.contains("mccafe mocha latte")
                         || here.contains("americano") || here.contains("mccafe premium roast coffee")
                         || here.contains("mccafe iced caramel macchiato") || here.contains("mccafé iced mocha latte")
                         || here.contains("mccafe iced coffee") || here.contains("mccafé iced caramel coffee")
                         || here.contains("mccafé iced french vanilla coffee") || here.contains("mccafé latte")
                         || here.contains("mccafé iced latte") || here.contains("mccafé caramel latte")
                         || here.contains("mccafé iced caramel latte") || here.contains("mccafé french vanilla latte")
                         || here.contains("mccafé iced french vanilla latte") || here.contains("mccafé caramel frappé")
                         || here.contains("mccafé mocha frappé")) {
                     total += 2.5; 
                        System.out.println("Total: $" + total);

                 }

                 else  if (here.contains("bacon, egg & cheese mcgriddles") || here.contains("sausage mcgriddles")
                               || here.contains("sausage, egg & cheese mcgriddles") || here.contains("big breakfast")
                               || here.contains("big breakfast with hotcakes") || here.contains("hotcakes")
                               || here.contains("hotcakes and sausage") || here.contains("sausage burrito")
                               || here.contains("hash browns") || here.contains("fruit & maple oatmeal")
                               || here.contains("egg mcmuffin meal") || here.contains("sausage mcmuffin with egg meal")
                               || here.contains("sausage biscuit with egg meal") || here.contains("bacon, egg & cheese biscuit meal")
                               || here.contains("bacon, egg & cheese mcgriddles meal")
                               || here.contains("sausage, egg & cheese mcgriddles meal") || here.contains("sausage mcgriddles meal")
                               || here.contains("sausage burrito meal")) {
                           total += 4.5; 
                          System.out.println("Total: $" + total);

                       }

                 else if (here.contains("mccrispy") || here.contains("deluxe mccrispy") || here.contains("spicy mccrispy")
                                 || here.contains("spicy chicken sandwich") || here.contains("fillet-o-fish") || here.contains("mcchicken")) {
                             total += 6; 
                          System.out.println("Total: $" + total);

                         }

                 else if (here.contains("world famous fries") || here.contains("apple slices") || here.contains("tangy barbeque sauce")
                                 || here.contains("spicy buffalo sauce") || here.contains("creamy ranch sauce") || here.contains("honey mustard sauce")
                                 || here.contains("honey") || here.contains("sweet 'n sour sauce") || here.contains("ketchup packet")
                                 || here.contains("mustard packet") || here.contains("mayonnaise packet")) {
                             total += 1.5; 
                          System.out.println("Total: $" + total);

                         }
                 else  if (here.contains("hamburger happy meal") || here.contains("4 piece chicken mcnuggets happy meal")
                                 || here.contains("6 piece chicken mcnuggets® happy meal")) {
                             total += 4.99; 
                          System.out.println("Total: $" + total);

                         }
                 else if (here.contains("mcflurry with oreo cookies") || here.contains("mcflurry with m&m's candies")
                                 || here.contains("vanilla cone") || here.contains("chocolate shake") || here.contains("vanilla shake")
                                 || here.contains("strawberry shake") || here.contains("hot fudge sundae") || here.contains("hot caramel sundae")
                                 || here.contains("baked apple pie") || here.contains("chocolate chip cookie")) {
                             total += 3.5; 
                          System.out.println("Total: $" + total);

                         }
                 else if (here.contains("chicken mcnuggets")) {
                             total += 4; 
                          System.out.println("Total: $" + total);

                         }


         return total;


 }


        public static String getRecommendationBasedOnTime() {
                ZoneId zone = ZoneId.of("America/Los_Angeles");  
                LocalTime now = LocalDateTime.now(zone).toLocalTime();
                System.out.println("Bot: Let me get a reccomendation for you based on the time.");
                if (now.isBefore(LocalTime.NOON)) {
                    return "Bot: How about a delicious breakfast sandwich? If yes, type in breakfast so I can get you that breakfast menu with all of our sanwich options";
                } else if (now.isBefore(LocalTime.of(18, 0))) {
                    return "Bot: It's the perfect time for a tasty burger! If thats what your craving, please type in burgers so I can get you that burger menu with our tasty burgers";
                } else {
                    return "Bot: How about you wind down your day with a McFlurry! If thats what your craving, please type in dessert so I can get you that delicious dessert menu with all of our McFlurrys";
                }
            }
}